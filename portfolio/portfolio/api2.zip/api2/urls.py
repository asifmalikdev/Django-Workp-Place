from api.urls import urlpatterns
from . import views
from django.urls import path

urlpatterns=[
    path('student_id_detail/<int:id>', views.students_id_view),

]
