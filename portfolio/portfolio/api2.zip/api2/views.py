from django.shortcuts import render
from .serializers import StudentsSerializers
from rest_framework import serializers
from .models import Students
from django.http import HttpResponse
from rest_framework.renderers import JSONRenderer

def students_id_view(request, id):
    stu = Students.objects.get(id = id)

    serializer = StudentsSerializers(stu)

    json_data = JSONRenderer.render(serializer.data)

    return HttpResponse(json_data, content_type='application/json')


# Create your views here.
